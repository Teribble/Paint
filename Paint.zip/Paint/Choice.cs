﻿namespace Paint.Mainform
{
    public enum Choice
    {
        Pensis = 1, Erase = 2, Ellipse = 3, Rectangle = 4, Line = 5, Fill = 6, Text = 7
    }
}
